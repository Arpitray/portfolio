thankyou for downloading.
this font is for Personal use.
dont use it for any commercial project.

link for buy : https://fontbundles.net/crumphand/1238214-orange-leaves
thank you, Regards!